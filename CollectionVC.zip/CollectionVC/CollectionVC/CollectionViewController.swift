//
//  CollectionViewController.swift
//  CollectionVC
//
//  Created by steve on 2020/9/6.
//  Copyright © 2020 steve. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"

class CollectionViewController: UICollectionViewController {
    
    private let values = [112.0, 116.0, 86.0, 95.0, 67.0, 76.0, 34.0, 43.0, 24.0, 35.0, 47.0, 66.0, 66.0, 57.0, 36.0, 64.0, 23.0, 22.0, 23.0, 22.0, 22.0, 22.0, 20.0, 23.0]
    private let itemSpace: CGFloat = 8
    private var itemWidth: CGFloat = 0
    private var countInOnePage: CGFloat = 12
    
    //MARK: -
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init(scrollDirection: UICollectionView.ScrollDirection = .horizontal) {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = scrollDirection
        super.init(collectionViewLayout: layout)
        
        self.collectionView!.delegate = self
        self.collectionView!.dataSource = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.collectionView.backgroundColor = .white
        self.itemWidth = (self.view.bounds.width - self.itemSpace*self.countInOnePage)/self.countInOnePage
        
        // Register cell classes
        self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
    }
    
    // MARK: - UICollectionViewDataSource
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return self.values.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath)
        
        let contentView = cell.contentView
        let row = indexPath.row
        
        //calculate height value
        let cellHeight = cell.frame.height
        var relativeHeight = 0.6 * cellHeight
        
        let Δvalue = values.max()! - values.min()!
        
        let value = values[row]
        if Δvalue != 0 {
            let different = value - values.min()!
            let ratio = CGFloat(different / Δvalue)
            relativeHeight = ratio * relativeHeight
        }
        
        if contentView.subviews.count == 0 {
            //layout timeLabel
            let timeLabel = UILabel()
            timeLabel.tag = 3
            timeLabel.font = UIFont.boldSystemFont(ofSize: 13)
            contentView.addSubview(timeLabel)
            
            timeLabel.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                timeLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -4),
                timeLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor)
            ])
            
            //layout valueView
            let valueView = UIView()
            valueView.tag = 1
            valueView.backgroundColor = UIColor.systemBlue
            
            contentView.addSubview(valueView)
            
            valueView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                valueView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
                valueView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
                valueView.bottomAnchor.constraint(equalTo: timeLabel.topAnchor, constant: -4),
                valueView.heightAnchor.constraint(equalToConstant: relativeHeight)
            ])
            
            //layout valueLabel
            let valueLabel = UILabel()
            valueLabel.tag = 2
            valueLabel.font = UIFont.systemFont(ofSize: 12)
            contentView.addSubview(valueLabel)
            
            valueLabel.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                valueLabel.bottomAnchor.constraint(equalTo: valueView.topAnchor, constant: -4),
                valueLabel.centerXAnchor.constraint(equalTo: valueView.centerXAnchor)
            ])
            
        }
        
        //set valueLabel text
        let valueLabel = contentView.viewWithTag(2) as! UILabel
        valueLabel.text = "\(values[row])"
        
        //set timeLabel value
        let timeLabel = contentView.viewWithTag(3) as! UILabel
        timeLabel.text = "\(row)"
        
        return cell
    }
    
}


//MARK: - UICollectionViewDelegateFlowLayout

extension CollectionViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let height: CGFloat = self.view.frame.height - 1
        
        return CGSize(width: self.itemWidth, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return self.itemSpace
    }
    
}
